# -*- coding: utf-8 -*-
"""
Curso NetOPS 19-24 mayo 2025

@author: Gonzalo M.F. 
gmartinez@­icm.csic.es

"""
###############################################################################
                            # DIRECTORIOS #
###############################################################################

base_dir          = "C:/Users/..../Curso_Cuenca_2025/"
rrs_dir_v0        = base_dir + "2_index_run/input/"
rrs_dir= base_dir + "2_index_run/output/"
index_dir= base_dir + "2_index_run/output/"
output_dirrrs = base_dir + "3_plot_run/rrs_output/" 
output_dirpcu = base_dir + "3_plot_run/pcu_output/" 
output_dirndci = base_dir + "3_plot_run/ndci_output/" 

###############################################################################
                            # IMPORTS #
###############################################################################
from matplotlib.ticker import (MultipleLocator)
import matplotlib.pyplot as plt
import numpy as np 
import os
import pandas as pd
os.chdir(base_dir + "3_plot_run/")
from plots_def import rrs_plot, ndci_plot, pcu_plot
from Smoo_filter import Smoo_filter
from datetime import datetime


###############################################################################
                            # PROCESADO #
###############################################################################

####empezamos por rrs

#abrimos el archivo hecho por el grupo 1
with open(rrs_dir+"rrs_fil.dat", "r") as doc:
        lines = doc.readlines()
# Procesar las líneas y dividirlas por ';'
linelist       = [line.strip().split(";") for line in lines]
# Convertir la lista de listas a un array de numpy
linelist       = np.array(linelist)
df             = pd.DataFrame(linelist)
df.columns     = df.iloc[0] # Asigna la primera fila como nombres de columnas
df             = df[1:]  

###############################################################################
                            # Rrs vs Rrs- efecto suelo (filtro) #
###############################################################################          
#necesitamos seleccionar solo la rrs de las columnas y la fecha doy y year

ID                  = df['Doy'].to_numpy().astype(str)
rrs                 = linelist[1:,1:].astype(float)
wl                  = list(range(400,902,2))
doy                 = [str(i[4:]) for i in ID]

#cambiamos fechas a normal para aislar meses
normal_fech              = ()
for f in ID:
    temp=datetime.strptime(f[0:4] + f[4:], "%Y%j").strftime("%d-%m-%Y")
    normal_fech=np.append(normal_fech,temp)

#seguimos por el archivo indices
#abrimos el archivo no filtrado (ubicacion distinta)

with open(rrs_dir_v0+"data.dat", "r") as doc:
        lines = doc.readlines()
# Procesar las líneas y dividirlas por ';'
linelist_v0      = [line.strip().split(";") for line in lines]
# Convertir la lista de listas a un array de numpy
linelist_v0       = np.array(linelist_v0)
rrs_v0                 = linelist_v0[1:,5:].astype(float)


fig                     =plt.figure(figsize=(15,10))
plt.plot(wl,np.nanmean(rrs,axis=0),color="black",label="Rrs")
plt.plot(wl,np.nanmean(rrs_v0,axis=0),color="red",label="Rrs_v0")
plt.legend()
fig.savefig(".....jpg",dpi=300)

#################################################################################
                            # lt y es - efecto suelo (filtro) #
###############################################################################     
###con la parte de arriba lo dejo un poco a probar 
#####

##############################################################################    
    #Rrs all_year
##############################################################################

year_data=np.nanmean(rrs,axis=0)
year_std= np.nanstd(rrs,axis=0)
rrs_plot(wl,year_data,output_dirrrs,"allyear")

##############################################################################    
    #Rrs plot today
##############################################################################
today               = max(ID)
today               = ID[np.where(ID=='2021001')[0]]             
rrs_today               = rrs[np.where(ID==today)]
todaymean               = np.nanmean(rrs_today,axis=0)
date                    = int(today)
rrs_plot(wl,todaymean,output_dirrrs,"today")

####esto hace un grafico diario del rrs
for r in range(len(ID)):
    rrs_plot(wl,rrs[r,:],output_dirrrs,str(ID[r]))




##############################################################################    
    #INDEX
##############################################################################

with open(index_dir+"index_data.dat", "r") as doc:
        lines = doc.readlines()
# Procesar las líneas y dividirlas por ';'
linelist_index       = [line.strip().split(";") for line in lines]
# Convertir la lista de listas a un array de numpy
linelist_index       = np.array(linelist_index)

# linelit declaration for the memory
index_data          = linelist_index[1:,1:].astype(float)
index_name          = linelist_index[0,1:]
index_all           = {}

######importante ahora lo extrapolamos a entre 0 y 1 para que todos sean comparables, ya que tienen distintos rangos
for j in range(len(index_data[0,:])):
    temp=((abs(index_data[:,j])-min(abs(index_data[:,j])))/(max(abs(index_data[:,j]))-min(abs(index_data[:,j]))))
    #temp=Smoo_filter(temp, 4) #suavizado
    index_all[index_name[j]]=temp
#name=list(index_all.keys())

chl_name=['Chla_NDCI', 'Chla_G08', 'chla_OC4Me', 'CHL_m', 'CHL2D_m', 'CHL2C_m', 'CHL_P', 'CHL2_P']
pcu_name=['PC_D', 'PC_SY', 'PC_S', 'PC_RV', 'PC_H3', 'PC_H1b',  'PC_L', 'PC_Br2' ]
ndci_all = index_all['NDCI']

#grafico ejemplo comparativa de indices clorofila y ndci

fig                     =plt.figure(figsize=(15,10))
ax                      =fig.add_axes([0.1,0.1,0.8,0.8])
ax.plot(normal_fech,index_all['NDCI'],color="green",label="NDCI")
ax.plot(normal_fech,index_all['Chla_G08'],color="black",label="NDCI")
ax.xaxis.set_major_locator(MultipleLocator(31))
for tick in ax.get_xticklabels():
    tick.set_rotation(45)
ax.set_ylabel("NDCI anf chl-a", fontsize=18)
ax.tick_params(axis='both', labelsize=20) 
ax.grid(True)
plt.legend()
fig.savefig("......jpg",dpi=300)


#ejemplo todas las clorofilas en una grafica
colores = [
    '#1f77b4',  # azul
    '#ff7f0e',  # naranja
    '#2ca02c',  # verde
    '#d62728',  # rojo
    '#9467bd',  # morado
    '#8c564b',  # marrón
    '#e377c2',  # rosa
    '#7f7f7f'   # gris
]
fig                     =plt.figure(figsize=(15,10))
ax                      =fig.add_axes([0.1,0.1,0.8,0.8])
for i in range(len(chl_name)):
    ax.plot(normal_fech,index_all[chl_name[i]],color=colores[i],label=chl_name[i])
ax.plot(normal_fech,index_all['NDCI'],color="black",label="NDCI")
ax.xaxis.set_major_locator(MultipleLocator(31))
for tick in ax.get_xticklabels():
    tick.set_rotation(45)
ax.set_ylabel("NDCI anf chl-a", fontsize=18)
ax.tick_params(axis='both', labelsize=20) 
ax.grid(True)
plt.legend()
fig.savefig("......jpg",dpi=300)

####lo mismo para pcu podeis escoger varias y comparar o todas... etc 
###ejemplo todas

colores = [
    '#1f77b4',  # azul
    '#ff7f0e',  # naranja
    '#2ca02c',  # verde
    '#d62728',  # rojo
    '#9467bd',  # morado
    '#8c564b',  # marrón
    '#e377c2',  # rosa
    '#7f7f7f'   # gris
]
fig                     =plt.figure(figsize=(15,10))
ax                      =fig.add_axes([0.1,0.1,0.8,0.8])
for i in range(len(chl_name)):
    ax.plot(normal_fech,index_all[pcu_name[i]],color=colores[i],label=pcu_name[i])
ax.xaxis.set_major_locator(MultipleLocator(31))
for tick in ax.get_xticklabels():
    tick.set_rotation(45)
ax.set_ylabel("PCu_Ratio", fontsize=18)
ax.tick_params(axis='both', labelsize=20) 
ax.grid(True)
plt.legend()
fig.savefig("......jpg",dpi=300)



##############################################################################    
    #NDCI desde rrs(nm) vs NDCI index
##############################################################################

#interpolar¿?












