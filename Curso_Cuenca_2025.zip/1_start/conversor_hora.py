# -*- coding: utf-8 -*-
"""
Created on Thu May 15 12:21:53 2025

@author: gmart
"""

#Separar la parte entera y la parte decimal:
valor=253.8958

doy = int(valor)

frac = valor - doy

#Convertir la fracción del día a horas, minutos y segundos:

horas = int(frac * 24)

minutos = int((frac * 24 - horas) * 60)

segundos = int((((frac * 24 - horas) * 60) - minutos) * 60)



